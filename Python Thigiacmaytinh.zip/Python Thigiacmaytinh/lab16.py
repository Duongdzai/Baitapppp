import tensorflow as tf
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from dataset_helper import load_custom_dataset

# 1. Tai va preprocess du lieu tu custom_dataset (Anh mau 32x32)
print("Dang tai du lieu tu custom_dataset...")
X, y, class_names = load_custom_dataset(base_path='custom_dataset', img_size=(32, 32), color_mode='rgb')
num_classes = len(class_names)

# MobileNetV2 can preprocess_input nhan vao anh kieu float co gia tri [0, 255]
X_preprocessed = tf.keras.applications.mobilenet_v2.preprocess_input(X * 255.0)

# Chia tap Train/Test (ty le 80/20)
x_train, x_test, y_train, y_test = train_test_split(X_preprocessed, y, test_size=0.2, random_state=42)

print(f"Kich thuoc tap Train: {x_train.shape}")
print(f"Kich thuoc tap Test: {x_test.shape}")
print(f"Cac lop phan lop: {class_names}")

# 2. Build MobileNetV2 Transfer Learning Model
# Su dung weights 'imagenet' va dong bang (freeze) cac layer goc
base = tf.keras.applications.MobileNetV2(input_shape=(32, 32, 3), include_top=False, weights='imagenet')
base.trainable = False

model = tf.keras.models.Sequential([
    base,
    tf.keras.layers.GlobalAveragePooling2D(),
    tf.keras.layers.Dropout(0.2),
    tf.keras.layers.Dense(num_classes, activation='softmax')
])

# 3. Train & Evaluate
model.compile(optimizer='adam', 
              loss='sparse_categorical_crossentropy', 
              metrics=['accuracy'])

# Huan luyen
history = model.fit(x_train, y_train, epochs=15, batch_size=32, validation_split=0.1)

# Danh gia
loss, acc = model.evaluate(x_test, y_test, verbose=0)
print(f"\nDo chinh xac tren tap Test: {acc * 100:.2f}%")

# 4. Plot bieu do ket qua huan luyen
plt.figure(figsize=(10, 4))
plt.subplot(1, 2, 1)
plt.plot(history.history['accuracy'], label='Train Acc')
plt.plot(history.history['val_accuracy'], label='Val Acc')
plt.title('Do chinh xac (Accuracy)')
plt.legend()

plt.subplot(1, 2, 2)
plt.plot(history.history['loss'], label='Train Loss')
plt.plot(history.history['val_loss'], label='Val Loss')
plt.title('Gia tri mat mat (Loss)')
plt.legend()

plt.tight_layout()
plt.show()
