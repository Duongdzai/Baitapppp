import tensorflow as tf
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from dataset_helper import load_custom_dataset

# 1. Tai va chuan hoa du lieu tu custom_dataset (Anh mau 32x32)
print("Dang tai du lieu tu custom_dataset...")
X, y, class_names = load_custom_dataset(base_path='custom_dataset', img_size=(32, 32), color_mode='rgb')
num_classes = len(class_names)

# Chia tap Train/Test (ty le 80/20)
x_train, x_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

print(f"Kich thuoc tap Train: {x_train.shape}")
print(f"Kich thuoc tap Test: {x_test.shape}")
print(f"Cac lop phan lop: {class_names}")

# 2. Xay dung mo hinh mang CNN don gian
model = tf.keras.models.Sequential([
    tf.keras.layers.Conv2D(32, (3, 3), activation='relu', input_shape=(32, 32, 3)),
    tf.keras.layers.MaxPooling2D((2, 2)),
    tf.keras.layers.Conv2D(64, (3, 3), activation='relu'),
    tf.keras.layers.MaxPooling2D((2, 2)),
    tf.keras.layers.Flatten(),
    tf.keras.layers.Dense(64, activation='relu'),
    tf.keras.layers.Dense(num_classes, activation='softmax')
])

# 3. Bien dich va huan luyen mo hinh
model.compile(optimizer='adam', 
              loss='sparse_categorical_crossentropy', 
              metrics=['accuracy'])

# Huan luyen
history = model.fit(x_train, y_train, epochs=15, batch_size=32, validation_split=0.1)

# 4. Danh gia tren tap test
loss, acc = model.evaluate(x_test, y_test, verbose=0)
print(f"\nDo chinh xac tren tap Test: {acc * 100:.2f}%")

# 5. Ve do thi ket qua
plt.figure(figsize=(10, 4))
plt.subplot(1, 2, 1)
plt.plot(history.history['accuracy'], label='Train Acc')
plt.plot(history.history['val_accuracy'], label='Val Acc')
plt.title('Do chinh xac (Accuracy)')
plt.legend()

plt.subplot(1, 2, 2)
plt.plot(history.history['loss'], label='Train Loss')
plt.plot(history.history['val_loss'], label='Val Loss')
plt.title('Gia tri mat mat (Loss)')
plt.legend()

plt.tight_layout()
plt.show()
