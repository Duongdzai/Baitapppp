import cv2 as cv
import numpy as np
import matplotlib.pyplot as plt
img = cv.imread('img/anhho.jpg', cv.IMREAD_GRAYSCALE)
if img is None:
    img = np.zeros((200, 200), dtype=np.uint8)
    cv.rectangle(img, (50, 50), (150, 150), 255, -1) # Vẽ hình vuông trắng
else:
    _, img = cv.threshold(img, 127, 255, cv.THRESH_BINARY)
kernel = np.ones((5, 5), np.uint8)
erosion = cv.erode(img, kernel, iterations=1)   # Phép bào mòn (làm mảnh nét)
dilation = cv.dilate(img, kernel, iterations=1) # Phép giãn nở (làm dày nét)
titles = ['Anh Goc', 'Bao Mon (Erode)', 'Gian No (Dilate)']
images = [img, erosion, dilation]

for i in range(3):
    plt.subplot(1, 3, i + 1)
    plt.imshow(images[i], cmap='gray')
    plt.title(titles[i])
    plt.xticks([]), plt.yticks([]) 

plt.show()