import os
import shutil
import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf
from tensorflow.keras import layers, models, optimizers
from PIL import Image, ImageDraw
# ==============================================================================
# 1. TU TAO DATASET SYNTHETIC (MOI LOP 3 ANH)
# ==============================================================================
def generate_synthetic_dataset(base_dir='custom_dataset_lab18', num_samples_per_class=3, img_size=(64, 64)):
    if os.path.exists(base_dir):
        shutil.rmtree(base_dir)

    print(f"--> Dang tu dong tao bo du lieu tai '{base_dir}' ({num_samples_per_class} anh/lop)...")
    classes = ['circle', 'square', 'triangle']
    np.random.seed(42)

    for cls in classes:
        cls_dir = os.path.join(base_dir, cls)
        os.makedirs(cls_dir, exist_ok=True)
        
        for i in range(num_samples_per_class):
            bg_color = tuple(np.random.randint(200, 256, size=3))
            img = Image.new('RGB', img_size, color=bg_color)
            draw = ImageDraw.Draw(img)
            
            shape_color = tuple(np.random.randint(0, 180, size=3))
            margin = 10
            x1 = np.random.randint(margin, img_size[0] // 2)
            y1 = np.random.randint(margin, img_size[1] // 2)
            x2 = np.random.randint(img_size[0] // 2, img_size[0] - margin)
            y2 = np.random.randint(img_size[1] // 2, img_size[1] - margin)
            
            if cls == 'circle':
                draw.ellipse([x1, y1, x2, y2], fill=shape_color)
            elif cls == 'square':
                draw.rectangle([x1, y1, x2, y2], fill=shape_color)
            elif cls == 'triangle':
                draw.polygon([(x1, y2), ((x1 + x2) // 2, y1), (x2, y2)], fill=shape_color)
            
            img_arr = np.array(img).astype(np.int16)
            noise = np.random.randint(-15, 15, img_arr.shape)
            img_arr = np.clip(img_arr + noise, 0, 255).astype(np.uint8)
            
            final_img = Image.fromarray(img_arr)
            final_img.save(os.path.join(cls_dir, f"{cls}_{i:03d}.png"))
            
    print("--> Tao dataset hoan tat!\n")
    return base_dir

def load_dataset(data_dir, img_size=(64, 64)):
    images, labels = [], []
    class_names = sorted([d for d in os.listdir(data_dir) if os.path.isdir(os.path.join(data_dir, d))])
    class_to_idx = {cls_name: i for i, cls_name in enumerate(class_names)}
    
    for cls in class_names:
        cls_dir = os.path.join(data_dir, cls)
        for fname in os.listdir(cls_dir):
            if fname.endswith(('.png', '.jpg', '.jpeg')):
                img_path = os.path.join(cls_dir, fname)
                img = Image.open(img_path).convert('RGB').resize(img_size)
                images.append(np.array(img))
                labels.append(class_to_idx[cls])
                
    return np.array(images, dtype=np.float32), np.array(labels, dtype=np.int64), class_names

# ==============================================================================
# 2. LOAD VA HIEN THI TRUC QUAN ANH DATASET
# ==============================================================================
IMG_SIZE = (64, 64)
dataset_dir = generate_synthetic_dataset(num_samples_per_class=3, img_size=IMG_SIZE)
X, y, class_names = load_dataset(dataset_dir, img_size=IMG_SIZE)
num_classes = len(class_names)

print(f"Tong so anh: {len(X)} ({len(X)//num_classes} anh/lop)")
print(f"Kich thuoc anh: {X.shape} | Cac lop: {class_names}\n")

# Cua so 1: Hien thi 9 anh trong dataset
plt.figure(figsize=(8, 8))
plt.suptitle("1. HIEN THI CAC ANH TRONG DATASET (3 ANH/LOP)", fontsize=12, fontweight='bold')
for i in range(len(X)):
    plt.subplot(3, 3, i + 1)
    plt.imshow(X[i].astype(np.uint8))
    plt.title(f"Lop thuc te: {class_names[y[i]]}")
    plt.axis('off')
plt.tight_layout()
plt.show()

x_train, y_train = X, y
x_test, y_test = X, y

# ==============================================================================
# 3. HUAN LUYEN PIPELINE
# ==============================================================================
def run_cnn_pipeline(model_type='MobileNetV2', unfreeze_layers=10, epochs_tl=3, epochs_ft=3):
    print("="*60)
    print(f" THU NGHIEM KIEN TRUC CNN: {model_type.upper()}")
    print("="*60)
    
    if model_type == 'MobileNetV2':
        preprocess_fn = tf.keras.applications.mobilenet_v2.preprocess_input
        base_model = tf.keras.applications.MobileNetV2(input_shape=(64, 64, 3), include_top=False, weights='imagenet')
    elif model_type == 'EfficientNetB0':
        preprocess_fn = tf.keras.applications.efficientnet.preprocess_input
        base_model = tf.keras.applications.EfficientNetB0(input_shape=(64, 64, 3), include_top=False, weights='imagenet')

    x_train_prep = preprocess_fn(x_train.copy())
    x_test_prep = preprocess_fn(x_test.copy())

    # Giai doan 1: Transfer Learning
    print(f"\n--- [Giai doan 1] Transfer Learning (Feature Extraction) - {model_type} ---")
    base_model.trainable = False
    model = models.Sequential([
        base_model,
        layers.GlobalAveragePooling2D(),
        layers.Dropout(0.2),
        layers.Dense(num_classes, activation='softmax')
    ])
    model.compile(optimizer=optimizers.Adam(learning_rate=1e-3),
                  loss='sparse_categorical_crossentropy', metrics=['accuracy'])
    
    print("\n--- CAU TRUC MODEL SUMMARY ---")
    model.summary()
    history_tl = model.fit(x_train_prep, y_train, epochs=epochs_tl, batch_size=3, verbose=1)

    # Giai doan 2: Fine-Tuning
    print(f"\n--- [Giai doan 2] Fine-Tuning - {model_type} ---")
    base_model.trainable = True
    fine_tune_at = max(0, len(base_model.layers) - unfreeze_layers)
    for layer in base_model.layers[:fine_tune_at]:
        layer.trainable = False

    model.compile(optimizer=optimizers.Adam(learning_rate=1e-5),
                  loss='sparse_categorical_crossentropy', metrics=['accuracy'])
    history_ft = model.fit(x_train_prep, y_train, epochs=epochs_ft, batch_size=3, verbose=1)

    loss_test, acc_test = model.evaluate(x_test_prep, y_test, verbose=0)
    preds = model.predict(x_test_prep, verbose=0)
    pred_labels = np.argmax(preds, axis=1)

    return history_tl, history_ft, acc_test, model, pred_labels

# ==============================================================================
# 4. CHAY MO HINH VA HIEN THI KET QUA DUDOAN & SO DO
# ==============================================================================
hist_tl_mb, hist_ft_mb, acc_mb, model_mb, preds_mb = run_cnn_pipeline('MobileNetV2', 10, 3, 3)
hist_tl_eff, hist_ft_eff, acc_eff, model_eff, preds_eff = run_cnn_pipeline('EfficientNetB0', 10, 3, 3)

# Cua so 2: Hien thi ket qua du doan cua MobileNetV2 tren anh thuc te
plt.figure(figsize=(8, 8))
plt.suptitle("2. KẾT QUẢ DỰ ĐOÁN CỦA MOBILENETV2 TRÊN TẬP ẢNH", fontsize=12, fontweight='bold')
for i in range(len(X)):
    plt.subplot(3, 3, i + 1)
    plt.imshow(X[i].astype(np.uint8))
    pred_name = class_names[preds_mb[i]]
    true_name = class_names[y[i]]
    color = 'green' if pred_name == true_name else 'red'
    plt.title(f"Dự đoán: {pred_name}\n(Thực tế: {true_name})", color=color, fontsize=10)
    plt.axis('off')
plt.tight_layout()
plt.show()

# Cua so 3: Do thi so sanh Do chinh xac (Accuracy Chart)
plt.figure(figsize=(12, 4.5))
acc_mb_all = hist_tl_mb.history['accuracy'] + hist_ft_mb.history['accuracy']
acc_eff_all = hist_tl_eff.history['accuracy'] + hist_ft_eff.history['accuracy']

plt.subplot(1, 2, 1)
plt.plot(acc_mb_all, marker='o', label='MobileNetV2 Acc', color='blue')
plt.axvline(x=2.5, color='gray', linestyle=':', label='Bat dau Fine-Tuning')
plt.title('MobileNetV2 Accuracy')
plt.xlabel('Epoch')
plt.ylabel('Accuracy')
plt.legend()

plt.subplot(1, 2, 2)
plt.plot(acc_eff_all, marker='s', label='EfficientNetB0 Acc', color='orange')
plt.axvline(x=2.5, color='gray', linestyle=':', label='Bat dau Fine-Tuning')
plt.title('EfficientNetB0 Accuracy')
plt.xlabel('Epoch')
plt.ylabel('Accuracy')
plt.legend()

plt.tight_layout()
plt.show()

print("\n" + "="*60)
print(" BANG TONG KET KET QUA SO SANH CAC KIEN TRUC CNN:")
print(f"- MobileNetV2     (Transfer Learning + Fine-Tuning): {acc_mb*100:.2f}%")
print(f"- EfficientNetB0  (Transfer Learning + Fine-Tuning): {acc_eff*100:.2f}%")
print("Tham khao chi tiet tai: https://keras.io/api/applications/")
print("="*60)
